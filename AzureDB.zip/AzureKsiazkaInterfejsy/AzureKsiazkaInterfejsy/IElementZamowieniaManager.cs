﻿using System;
using System.Collections.Generic;
using System.Text;
using Modele;

namespace Interfejsy
{
    public interface IElementZamowieniaManager:IBaseManager<ElementZamowienia>
    {
    }
}
