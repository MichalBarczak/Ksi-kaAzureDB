﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AzureKsiazkaInterfejsy;
using AzureKsiazkaModele;
namespace AzureKsiazkaMenager
{
    public class TypProduktuMenager : ITypProduktuManager
    {
        public bool Edytuj(TypProduktu item)
        {
            throw new NotImplementedException();
        }

        public TypProduktu PobierzElement(Guid id)
        {
            throw new NotImplementedException();
        }

        public List<TypProduktu> PobierzElementy()
        {
            throw new NotImplementedException();
        }

        public bool Usuń(TypProduktu item)
        {
            throw new NotImplementedException();
        }

        public bool Utwórz(TypProduktu item)
        {
            throw new NotImplementedException();
        }
    }
}
