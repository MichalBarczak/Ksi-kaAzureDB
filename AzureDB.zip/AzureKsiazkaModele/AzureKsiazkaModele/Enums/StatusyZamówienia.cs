﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Modele.Enums
{
    public enum StatusyZamówienia
    {
        Zarezrwowane=1,
        Zapłacone=2,
        Wysłane=3,
        Dostarczone=4,
        Anulowane=5
    }
}
