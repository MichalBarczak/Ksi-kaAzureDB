﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Modele.Enums
{
   public  enum Role
    { 
        Klient=1,
        Sprzedawca=2,
        Administrator=3

    }
}
