﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Modele.Enums
{
    public enum MetodyPlatnosci
    {
        Gotowka=1,
        Karta_Kredytowa=2,
        Transfer=3,
        eBankowość=4
    }
}
