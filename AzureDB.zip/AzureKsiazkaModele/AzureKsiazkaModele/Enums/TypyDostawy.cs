﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Modele.Enums
{
    public enum TypyDostawy
    {
        Kurier=1,
        Paczkomat=2,
        Paczak_Pocztowa=3,

    }
}
