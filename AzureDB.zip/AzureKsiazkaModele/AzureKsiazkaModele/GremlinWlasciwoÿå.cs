﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Modele
{
    public class GremlinWlasciwość
    {
        public GremlinWartość[] IdTypu { get; set; }
        public GremlinWartość[] IdProducenta { get; set; }
        public GremlinWartość[] Nazwa { get; set; }
        public GremlinWartość[] Opis { get; set; }
        public GremlinWartość[] Cena { get; set; }
        public GremlinWartość[] NazwaProducenta { get; set; }
        public GremlinWartość[] NazwaTypu { get; set; }
        public GremlinWartość[] Id { get; set; }
        public GremlinWartość[] pk { get; set; }

    }
}
